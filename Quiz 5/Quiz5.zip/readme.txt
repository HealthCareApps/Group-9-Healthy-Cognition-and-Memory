1.Screen shot of a fragment in the application
2.Application Project