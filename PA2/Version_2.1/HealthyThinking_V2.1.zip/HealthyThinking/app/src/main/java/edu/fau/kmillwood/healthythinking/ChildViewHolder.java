package edu.fau.kmillwood.healthythinking;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by Khalil on 4/8/2016.
 */
public class ChildViewHolder extends RecyclerView.ViewHolder {

    public ChildViewHolder(View itemView){

        super(itemView);
    }
}
