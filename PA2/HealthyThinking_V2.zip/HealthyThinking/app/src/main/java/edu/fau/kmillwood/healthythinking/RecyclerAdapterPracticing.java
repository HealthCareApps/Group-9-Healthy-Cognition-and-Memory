package edu.fau.kmillwood.healthythinking;

import android.support.design.widget.Snackbar;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class RecyclerAdapterPracticing extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private String[] positivePracticingTitles = {
            "GENERAL",
            "Only Use Positive Words When Talking",
            "Push Out All Feelings That Aren't Positive",
            "Positive Affirmation",
            "Believe You Will Succeed",
            "Analyze What Went Wrong",
            "Forgive Yourself",
            "Learn From The Past",
            "Think Of It As An Opportunity",
            "AT WORK",
            "Be Constructive",
            "Visualize A Successful Outcome",
            "Surround Yourself With Positive Images",
            "Relax And Let Things Happen",
            "See It From Another Point Of View",
            "Don't Dwell",
            "Stop Being Your Own Worst Critic",
            "Believe In Yourself",
            "Avoid Negative Coworkers",
            "Look For Opportunity",
            "FAMILY AND PERSONAL LIFE",
            "Associate Yourself With Those Who Think Positively",
            "Benefit From The Attitudes Of Others",
            "Find Someone To Share With",
            "Do Something Nice",
            "Indulge Yourself",
            "Remind Yourself Of Your Blessings",
            "Avoid Laying Blame",
            "Be Playful",
            "FUN AND RELAXATION",
            "Read An Inspiring Book",
            "Watch Your Favorite Movie",
            "Take A Break From The News",
            "Listen To Some Feel Good Music",
            "Mediate",
            "Explore The World Around You",
            "Create Something",
            "FACING CHALLENGES",
            "Fake It Till You Make It",
            "Understand The Obstacles Are There To Challenge",
            "Start Small",
            "Don\'t Let Yourself Quit",
            "Don\'t Expect Change To Be Easy",
            "Find The Bright Side",
            "Understand That The Situation Is Not Forever",
            "Truly Believe You Will Succeed",
            "DAILY ATTITUDE",
            "See The Beauty In Everything",
            "Realize That Your Thoughts Do Not Own You",
            "Accept The Good Things",
            "Believe That There Is Good In The World",
            "Stop Making Excuses",
            "Don\'t Place Your Future In Someone Else\'s Hands",
            "Take Control Of Your Decisions",
            "Create Realistic Goals",
            "Decide Why You Want What You Want",
            "Look At Things With Fresh Eyes"


    };

    private String[] positivePracticingText = {
            ""
    };

    class ViewHolder extends RecyclerView.ViewHolder {
        public TextView itemTitle;
        //public TextView itemText;

        public ViewHolder(View itemView){
            super(itemView);
            itemTitle = (TextView)itemView.findViewById(R.id.practicingTitle);
            //itemText = (TextView)itemView.findViewById(R.id.practicingText);
            itemView.setOnClickListener(new	View.OnClickListener()	{
                @Override public void onClick(View v) {
                    int	position = getAdapterPosition();
                    Snackbar.make(v,"Click detected	on	item "+	position, Snackbar.LENGTH_LONG).setAction("Action",	null).show();
                }
            });
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.practicing_card_layout, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int i) {
        ViewHolder viewHolder = (ViewHolder)holder;
        viewHolder.itemTitle.setText(positivePracticingTitles[i]);
        //viewHolder.itemText.setText(positivePracticingText[i]);
    }
    @Override public int getItemCount(){
        return positivePracticingTitles.length;
    }

}